# README
## github 
git clone https://github.com/ahjszhx/5031_p1.git

## How to build it
mvn clean package

## How to run Junit Test
mvn test

## How to run it
java -jar target/Hangman-1.0.jar

## How to generate java doc
mvn javadoc:javadoc

